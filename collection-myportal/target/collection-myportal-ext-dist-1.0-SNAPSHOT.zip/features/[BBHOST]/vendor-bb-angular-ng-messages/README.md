# vendor-bb-angular-ng-messages

ngMessages is a directive that is designed to show and hide messages based on the state of a key/value object that it listens on. The directive itself complements error message reporting with the ngModel $error object (which stores a key/value state of validation errors).

https://docs.angularjs.org/api/ngMessages
