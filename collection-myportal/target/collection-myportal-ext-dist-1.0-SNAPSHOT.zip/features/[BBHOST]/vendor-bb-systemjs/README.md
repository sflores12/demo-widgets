# vendor-bb-systemjs

Universal dynamic module loader - loads ES6 modules, AMD, CommonJS and global scripts in the browser and NodeJS.

https://github.com/systemjs/systemjs/blob/master/README.md
