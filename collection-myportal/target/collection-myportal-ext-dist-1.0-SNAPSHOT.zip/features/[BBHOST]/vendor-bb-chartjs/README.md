# vendor-bb-chartjs

Simple yet flexible JavaScript charting for designers & developers

http://www.chartjs.org/docs/latest/
