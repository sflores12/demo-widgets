# vendor-bb-angular-ng-aria

> The goal of ngAria is to improve Angular's default accessibility by enabling common ARIA attributes that convey state or semantic information for assistive technologies used by persons with disabilities.

- [ng-aria](https://docs.angularjs.org/api/ngAria)
- [ng-aria accessibility guide](https://docs.angularjs.org/guide/accessibility)
