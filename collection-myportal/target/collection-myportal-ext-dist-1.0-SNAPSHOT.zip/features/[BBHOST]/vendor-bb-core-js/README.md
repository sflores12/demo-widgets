# vendor-bb-core-js

Modular standard library for JavaScript.
Includes polyfills for ECMAScript 5, ECMAScript 6: promises, symbols, collections, iterators, typed arrays, ECMAScript 7+ proposals, setImmediate, etc.

https://github.com/zloirock/core-js/blob/master/README.md
