import widget from './index';

describe('Widget Mobile Product Summary', () => {
  it('should export the module name', () => {
    expect(widget).toEqual('widget-bbm-product-summary-ng');
  });
});
