import widget from './index';

describe('widget-bb-transactions-ng', function () {
  it('should export the module name', function () {
    expect(widget).toEqual('widget-bb-transactions-ng');
  });
});
