import widget from './index';

describe('Turnovers', () => {
  it('should export the module name', () => {
    expect(widget).toEqual('widget-bb-turnovers-ng');
  });
});
