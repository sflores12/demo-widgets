import widget from './index';

describe('Manage Products', () => {
  it('should export the module name', () => {
    expect(widget).toEqual('widget-bb-manage-products-ng');
  });
});
