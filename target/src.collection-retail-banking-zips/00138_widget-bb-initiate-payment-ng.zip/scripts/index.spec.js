import widget from './index';

describe('Initiate Payment', () => {
  it('should export the module name', () => {
    expect(widget).toEqual('widget-bb-initiate-payment-ng');
  });
});
