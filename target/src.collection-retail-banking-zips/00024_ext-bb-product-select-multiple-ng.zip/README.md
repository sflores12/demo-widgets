# ext-bb-product-select-multiple-ng

Extension for widget-bb-product-summary-ng to select multiple products.

