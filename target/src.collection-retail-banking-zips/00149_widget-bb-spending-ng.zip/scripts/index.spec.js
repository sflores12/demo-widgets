import widget from './index';

describe('Spending', () => {
  it('should export the module name', () => {
    expect(widget).toEqual('widget-bb-spending-ng');
  });
});
