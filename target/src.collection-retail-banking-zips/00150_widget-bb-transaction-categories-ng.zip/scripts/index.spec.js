import widget from './index';

describe('Transaction Categories', () => {
  it('should export the module name', () => {
    expect(widget).toEqual('widget-bb-transaction-categories-ng');
  });
});
