# ext-bb-product-select-ng

Extension for widget-bb-product-summary-ng to select a product.

