import widget from './index';

describe('Widget Notifications Popups', function() {
  it('should export the module name', function() {
    expect(widget).toEqual('widget-bb-notification-popups-ng');
  });
});
