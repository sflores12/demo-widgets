import widget from './index';

describe('Income/Spending analysis by category widget', () => {
  it('should export the module name', () => {
    expect(widget).toEqual('widget-bb-income-spending-analysis-category-ng');
  });
});
