# ext-bb-personal-profile-ng

Default extension for widget-bb-personal-profile-ng
