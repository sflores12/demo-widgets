export const Events = {
};

export const Text = {
  ERROR_AUTH: 'places.error.ERROR_AUTH',
  ERROR_CONNECTION: 'places.error.ERROR_CONNECTION',
  ERROR_UNEXPECTED: 'places.error.ERROR_UNEXPECTED',
  ERROR_USER: 'places.error.ERROR_USER',
};
