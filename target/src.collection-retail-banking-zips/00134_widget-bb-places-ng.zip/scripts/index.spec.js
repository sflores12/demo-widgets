import widget from './index';

describe('Places', () => {
  it('should export the module name', () => {
    expect(widget).toEqual('widget-bb-places-ng');
  });
});
