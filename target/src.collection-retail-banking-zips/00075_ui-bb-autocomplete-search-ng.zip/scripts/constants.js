export const MODULE_KEY = 'ui-bb-autocomplete-search-ng';

export const CONTROLLER_KEY = `${MODULE_KEY}:controller`;

export const COMPONENT_KEY = 'uiBbAutocompleteSearchNg';

export const POPUP_TEMPLATE_URL = `${MODULE_KEY}/popup-template.html`;

export const MATCH_TEMPLATE_URL = `${MODULE_KEY}/match-template.html`;
