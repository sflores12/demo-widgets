import widget from './index';

describe('Widget Product Summary', function() {
  it('should export the module name', function() {
    expect(widget).toEqual('widget-bb-product-summary-ng');
  });
});
