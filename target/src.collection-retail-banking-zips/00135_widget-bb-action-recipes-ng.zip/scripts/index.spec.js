import widget from './index';

describe('Action Recipes', () => {
  it('should export the module name', () => {
    expect(widget).toEqual('widget-bb-action-recipes-ng');
  });
});
