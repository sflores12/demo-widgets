import widget from './index';

describe('Notifications model, main file', function() {
  it('should export the module name', function() {
    expect(widget).toEqual('model-bb-notifications-ng');
  });
});
