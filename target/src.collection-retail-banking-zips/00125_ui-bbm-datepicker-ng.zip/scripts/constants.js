export const MODULE_KEY = 'ui-bbm-datepicker-ng';

export const CONTROLLER_KEY = `${MODULE_KEY}:controller`;

export const COMPONENT_KEY = 'uiBbmDatepickerNg';

export const DATEPICKER_INTERNAL_DATE_FORMAT = 'yyyy-MM-ddTHH:mm:ssZ';
