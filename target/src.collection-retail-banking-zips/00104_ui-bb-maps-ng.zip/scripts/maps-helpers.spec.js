import angular from 'vendor-bb-angular';
import 'angular-mocks';

import helper from './maps-helpers';
import { Preference } from './constants';

describe('ui-bb-maps-ng::maps-helpers', function() {

});
