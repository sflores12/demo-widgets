/**
 * @name Events
 * @type {object}
 *
 * @description
 * Event subscribtions object for the extension
 */
export default () => ({});
