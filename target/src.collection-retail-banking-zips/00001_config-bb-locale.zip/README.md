# config-bb-locale
