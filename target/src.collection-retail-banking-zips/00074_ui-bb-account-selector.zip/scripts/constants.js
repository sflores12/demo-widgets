const FORMAT_AMOUNT_TEMPLATE_URL = 'ui-bb-account-selector/format-amount-template.html';

export default FORMAT_AMOUNT_TEMPLATE_URL;
