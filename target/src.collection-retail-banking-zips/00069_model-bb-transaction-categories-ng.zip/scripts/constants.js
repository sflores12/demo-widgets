/**
 * @name bbStorageKeys
 * @description
 * bbStorage keys enum
 * @type {object}
 */
const bbStorageKeys = {
  TRANSACTION_CATEGORIES_LIST: 'bb.transaction.categories.list',
};

export default bbStorageKeys;
