import widget from './index';

describe('widget-bbm-personal-profile-ng', () => {
  it('should export the module name', () => {
    expect(widget).toEqual('widget-bbm-personal-profile-ng');
  });
});
