export const MODULE_KEY = 'ui-bbm-list-ng';

export const COMPONENT_KEY = 'uiBbmList';

export const Platform = {
  IOS: 'ios',
  ANDROID: 'android',
};
