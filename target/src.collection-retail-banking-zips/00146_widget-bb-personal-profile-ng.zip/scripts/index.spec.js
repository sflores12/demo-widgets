import widget from './index';

describe('widget-bb-personal-profile-ng', function () {
  it('should export the module name', function () {
    expect(widget).toEqual('widget-bb-personal-profile-ng');
  });
});
