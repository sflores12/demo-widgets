import widget from './index';

describe('widget-bb-budget-ng', () => {
  it('should export the module name', () => {
    expect(widget).toEqual('widget-bb-budget-ng');
  });
});
