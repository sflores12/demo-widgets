import widget from './index';

describe('Widget Notifications Badge', function() {
  it('should export the module name', function() {
    expect(widget).toEqual('widget-bb-notification-badge-ng');
  });
});
