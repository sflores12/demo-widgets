const FORMAT_AMOUNT_TEMPLATE_URL = 'ui-bb-credit-suggest-ng/format-amount-template.html';

export default FORMAT_AMOUNT_TEMPLATE_URL;
