export const MODULE_KEY = 'ui-bbm-scroll-ng';

export const COMPONENT_KEY = 'uiBbmScrollNg';

export const Platform = {
  IOS: 'ios',
  ANDROID: 'android',
};
