# ext-bb-product-selected-ng

Extension for widget-bb-product-summary-ng to show currently selected product.
