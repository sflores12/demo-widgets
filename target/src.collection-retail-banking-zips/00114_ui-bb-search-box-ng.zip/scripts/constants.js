export const MODULE_KEY = 'ui-bb-search-box-ng';

export const CONTROLLER_KEY = `${MODULE_KEY}:controller`;

export const COMPONENT_KEY = 'uiBbSearchBoxNg';
