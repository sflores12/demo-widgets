export const MODULE_KEY = 'ui-bbm-maxlength-ng';

export const DIRECTIVE_KEY = 'uiBbmMaxlength';
