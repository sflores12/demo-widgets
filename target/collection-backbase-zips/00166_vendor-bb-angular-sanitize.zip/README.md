# vendor-bb-angular-sanitize

> The ngSanitize module provides functionality to sanitize HTML.

[AngularJS Sanitize](http://docs.angularjs.org/api/ngSanitize)
