# vendor-bb-ng-file-upload

Lightweight Angular directive to upload files with optional FileAPI shim for cross browser support.

https://github.com/danialfarid/ng-file-upload/blob/master/README.md
